var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["823faff5-1e16-4ceb-84cd-39e4bda760c7","5ce6a5fd-ee7c-457a-95c8-eeff11cb6dc8","251332b3-7aeb-40af-ac0f-1cceb3d1db5b","a8f36482-803d-4474-94a6-b14b425df10b","54c7b714-082d-432f-b761-58b3991e4165","ffb1d29d-0d1e-4c3a-a03e-fea6a55027e7","16277792-5134-4ceb-ab00-1c7170d98e6f"],"propsByKey":{"823faff5-1e16-4ceb-84cd-39e4bda760c7":{"name":"red","sourceUrl":null,"frameSize":{"x":29,"y":74},"frameCount":1,"looping":true,"frameDelay":12,"version":"e3EOe4K.8G1tpmXfjRwEkyAy4vxAQIhu","loadedFromSource":true,"saved":true,"sourceSize":{"x":29,"y":74},"rootRelativePath":"assets/823faff5-1e16-4ceb-84cd-39e4bda760c7.png"},"5ce6a5fd-ee7c-457a-95c8-eeff11cb6dc8":{"name":"green","sourceUrl":null,"frameSize":{"x":29,"y":74},"frameCount":1,"looping":true,"frameDelay":12,"version":"bzI0tTAT2EX0U2RSq21VmhrZrEvusbDy","loadedFromSource":true,"saved":true,"sourceSize":{"x":29,"y":74},"rootRelativePath":"assets/5ce6a5fd-ee7c-457a-95c8-eeff11cb6dc8.png"},"251332b3-7aeb-40af-ac0f-1cceb3d1db5b":{"name":"blue","sourceUrl":null,"frameSize":{"x":29,"y":74},"frameCount":1,"looping":true,"frameDelay":12,"version":"LKm_BQIBWujJPBjX8nVYf3RQYvhRtfsR","loadedFromSource":true,"saved":true,"sourceSize":{"x":29,"y":74},"rootRelativePath":"assets/251332b3-7aeb-40af-ac0f-1cceb3d1db5b.png"},"a8f36482-803d-4474-94a6-b14b425df10b":{"name":"yellow","sourceUrl":null,"frameSize":{"x":29,"y":74},"frameCount":1,"looping":true,"frameDelay":12,"version":"8Qz5QzuFC_l54BXJ6kJTpbtk30uMOlsk","loadedFromSource":true,"saved":true,"sourceSize":{"x":29,"y":74},"rootRelativePath":"assets/a8f36482-803d-4474-94a6-b14b425df10b.png"},"54c7b714-082d-432f-b761-58b3991e4165":{"name":"arrow","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"0NH6p0IEczChkQhzCR6Or9aSya4tsKhZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/54c7b714-082d-432f-b761-58b3991e4165.png"},"ffb1d29d-0d1e-4c3a-a03e-fea6a55027e7":{"name":"bow","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"pjh2PPpAQjI4h1JQvxg_2f1Dn.b7Sv5v","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/ffb1d29d-0d1e-4c3a-a03e-fea6a55027e7.png"},"16277792-5134-4ceb-ab00-1c7170d98e6f":{"name":"sunshine_showers_1","sourceUrl":"assets/api/v1/animation-library/gamelab/aKdIMfQ6ZOpZAiQLYFZjgwSjbxifm1eU/category_backgrounds/sunshine_showers.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"aKdIMfQ6ZOpZAiQLYFZjgwSjbxifm1eU","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/aKdIMfQ6ZOpZAiQLYFZjgwSjbxifm1eU/category_backgrounds/sunshine_showers.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var scene=createSprite(0,0,400,400); 
scene.setAnimation("sunshine_showers_1");

scene.scale=2;

scene.velocityX=-2;

scene.x=scene.width/2;

var bow=createSprite(380,190,100,100);
bow.setAnimation("bow");



var RedB=createGroup();
var GreenB=createGroup();
var BlueB=createGroup();
var YellowB=createGroup();
var arrowGroup=createGroup();


//set text
textSize(20);


//score
var score = 0;

function draw() {
  
  var select_balloon = randomNumber(1,4);
if(World.frameCount % 80==0){
if(select_balloon==1){
  redballoon();
}else if(select_balloon==2){
greenballoon();
}else if(select_balloon==3){
blueballoon();
}else if(select_balloon==4){
yellowballoon();  
}
}

if (scene.x<0) {
    scene.x=scene.width/2;
  }
  bow.y = World.mouseY;
  
  
    
  
  
if(arrowGroup.isTouching(RedB)){  
 RedB.destroyEach(); 
 arrowGroup.destroyEach();
 score=score+1; 
} 
  
if(arrowGroup.isTouching(GreenB)){  
 GreenB.destroyEach(); 
 arrowGroup.destroyEach();
 score=score+3; 
} 

if(arrowGroup.isTouching(YellowB)){  
 YellowB.destroyEach(); 
 arrowGroup.destroyEach();
 score=score+5; 
} 

if(arrowGroup.isTouching(BlueB)){  
 BlueB.destroyEach(); 
 arrowGroup.destroyEach();
 score=score+2; 
} 
  
  
  
 if (keyDown("space")) {
   createArrow();}
     

drawSprites();

text("Score: "+ score, 270, 30);


}


function redballoon(){
var red=createSprite(0,randomNumber(40,350),10,10);
red.setAnimation("red");
red.velocityX=5;
red.lifetime=150; 
RedB.add(red);
}  

function greenballoon(){
var green=createSprite(0,randomNumber(20,290),10,10);
green.setAnimation("green");
green.velocityX=4;
green.lifetime=150;
GreenB.add(green);
}  

function yellowballoon(){
var yellow=createSprite(0,randomNumber(55,225),10,10);
yellow.setAnimation("yellow");
yellow.velocityX=6;
yellow.lifetime=150; 
YellowB.add(yellow);
}

function blueballoon(){
var blue=createSprite(0,randomNumber(90,320),10,10);
blue.setAnimation("blue");
blue.velocityX=2;
blue.lifetime=220;  
BlueB.add(blue);
}  

function createArrow(){
  
var arrow=createSprite(100,100,60,10);
arrow.setAnimation("arrow");
arrow.x=300;  
arrow.y=bow.y;  
arrow.velocityX=-4 ;  
arrow.lifetime = 80; 
arrowGroup.add(arrow); 
playSound("assets/category_whoosh/airy_whoosh.mp3");
  
}
  
  
  
  
  


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
